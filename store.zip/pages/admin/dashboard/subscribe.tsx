import React from 'react'

const Subscribe = () => {
  return (
    <div>Subscribe</div>
  )
}

export default Subscribe