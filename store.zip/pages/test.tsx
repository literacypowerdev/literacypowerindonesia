import React from 'react'
import CarouselDocumentation from '../components/organisms/CarouselDocumentation'
import Pagination from '../components/organisms/Pagination'
import Yes from '../components/organisms/Pagination/yes'
import Reviews from '../components/organisms/Reviews'




const test = () => {
  return (
    <div>
      <CarouselDocumentation />
      <br />
      <br />
      <br />
      <br />
      <br />
      <Reviews />
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <br />
      <Pagination />
      <Yes />
    </div>


  )
}

export default test