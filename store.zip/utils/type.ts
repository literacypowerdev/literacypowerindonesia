type DampakModel = {
    title: string
    id_dampak: number;
    deskripsi: string;
    link_foto: string;
}

export default DampakModel