export const ReviewSlider = [
    {
        'id': '1',
        'reviews': '“Pengalaman memorable banget bisa mengikuti volunteering bersama Literacy Power, membagikan buku donasi untuk adik-adik di pesantren Para stakeholder pun sangat antusias membantu kami. Tempatnya pun sangat nyaman dan indah, masih hijau meskipun memakan cukup waktu yang lama dari kota.”',
        'reviewer': 'Adin, Mahasiswa Universitas Pendidikan Indonesia'
    },
    {
        'id': '2',
        'reviews': '“Pengalaman memorable banget bisa mengikuti volunteering bersama Literacy Power, membagikan buku donasi untuk adik-adik di pesantren Para stakeholder pun sangat antusias membantu kami. Tempatnya pun sangat nyaman dan indah, masih hijau meskipun memakan cukup waktu yang lama dari kota.”',
        'reviewer': 'Adin, Mahasiswa Universitas Pendidikan Indonesia'
    },
    {
        'id': '3',
        'reviews': '“Pengalaman memorable banget bisa mengikuti volunteering bersama Literacy Power, membagikan buku donasi untuk adik-adik di pesantren Para stakeholder pun sangat antusias membantu kami. Tempatnya pun sangat nyaman dan indah, masih hijau meskipun memakan cukup waktu yang lama dari kota.”',
        'reviewer': 'Adin, Mahasiswa Universitas Pendidikan Indonesia'
    }
]