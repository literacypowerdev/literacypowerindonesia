export const imageList = [
    '/images/fotoslider1.png',
    '/images/fotoslider2.png',
    '/images/fotoslider3.png',
    '/images/fotoslider4.png',
    '/images/fotoslider5.png',
    '/images/fotoslider6.png',
  ]
