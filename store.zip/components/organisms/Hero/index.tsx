import React from "react";

export default function Hero() {
  return (
    <div className="bg-hero bg-cover bg-top h-[250px] sm:h-[280px] lg:h-[320px] xl:h-[380px] w-full"></div>
  );
}
