"use strict";
(() => {
var exports = {};
exports.id = 332;
exports.ids = [332];
exports.modules = {

/***/ 6023:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ galery),
  "getServerSideProps": () => (/* binding */ getServerSideProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/admin/layout.tsx + 1 modules
var layout = __webpack_require__(7962);
// EXTERNAL MODULE: external "axios"
var external_axios_ = __webpack_require__(2167);
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_);
// EXTERNAL MODULE: external "next-cookies"
var external_next_cookies_ = __webpack_require__(7486);
var external_next_cookies_default = /*#__PURE__*/__webpack_require__.n(external_next_cookies_);
;// CONCATENATED MODULE: ./components/admin/galeryForm.tsx


const Cookie = __webpack_require__(6734);
const GaleryForm = ()=>{
    const token = Cookie.get("token");
    const { 0: image , 1: setImage  } = (0,external_react_.useState)("https://fakeimg.pl/1280x720/");
    const { 0: saveImage , 1: setSaveImage  } = (0,external_react_.useState)(null);
    const handleUploadImage = (e)=>{
        let uploaded = e.target.files[0];
        setImage(URL.createObjectURL(uploaded));
        setSaveImage(uploaded);
    };
    const handleSubmit = async ()=>{
        let formData = new FormData();
        formData.append("file", saveImage);
        try {
            const response = await fetch("https://api.literacypowerid.com/api/galery", {
                method: "POST",
                headers: {
                    "Authorization": "Bearer " + token
                },
                body: formData
            });
            const res = await response.json;
            console.log(res);
            window.location.reload();
        } catch (err) {
            console.log("ERROR: ", err);
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "text-black flex flex-col gap-5",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    className: "w-[400px]",
                    src: image,
                    alt: ""
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                type: "file",
                onChange: handleUploadImage
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("button", {
                className: "text-white px-4 py-2 rounded-lg bg-main-green w-fit",
                onClick: handleSubmit,
                children: "submit gambar"
            })
        ]
    });
};
/* harmony default export */ const galeryForm = (GaleryForm);

;// CONCATENATED MODULE: ./pages/admin/dashboard/galery.tsx






const galery_Cookie = __webpack_require__(6734);
const Galery = ({ data  })=>{
    const cookieToken = galery_Cookie.get("token");
    const handleDelete = async (id)=>{
        try {
            await external_axios_default()["delete"](`https://api.literacypowerid.com/api/galery/${id}`, {
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": "Bearer " + cookieToken
                }
            });
            window.location.reload();
        } catch (err) {
            galery_Cookie.remove("token");
        }
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(layout/* default */.Z, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "w-full flex flex-col",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(galeryForm, {}),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "grid xl:grid-cols-4 lg:grid-cols-3 md:grid-cols-2 sm:grid-cols-1 gap-10",
                    children: data && data.map((item, index)=>{
                        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "max-w-[400px]",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    className: "text-red-500 break-words",
                                    children: item.filename
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "w-full h-auto",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: `https://api.literacypowerid.com/images/${item.filename}`,
                                        alt: ""
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    onClick: ()=>handleDelete(item.id_galery),
                                    className: "bg-red-500 hover:bg-red-300 h-fit w-fit px-3 py-1 rounded-sm text-white self-end",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        children: "delete"
                                    })
                                })
                            ]
                        }, item.id_galery);
                    })
                })
            ]
        })
    });
};
const getServerSideProps = async (context)=>{
    const allCookies = external_next_cookies_default()(context);
    const token = allCookies.token;
    console.log(token);
    try {
        const res = await external_axios_default().get("https://api.literacypowerid.com/api/galery/admin", {
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + token
            }
        });
        const response = await res.data.data;
        return {
            props: {
                data: response
            }
        };
    } catch (e) {
        console.log("ini responnya: ", e.response.status);
        if (e.response.status !== 200) {
            return {
                redirect: {
                    destination: "/",
                    permanent: false
                }
            };
        }
    }
};
/* harmony default export */ const galery = (Galery);


/***/ }),

/***/ 2167:
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ 6734:
/***/ ((module) => {

module.exports = require("js-cookie");

/***/ }),

/***/ 7486:
/***/ ((module) => {

module.exports = require("next-cookies");

/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [676,664,962], () => (__webpack_exec__(6023)));
module.exports = __webpack_exports__;

})();