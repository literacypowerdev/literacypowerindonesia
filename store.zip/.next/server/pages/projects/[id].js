"use strict";
(() => {
var exports = {};
exports.id = 92;
exports.ids = [92];
exports.modules = {

/***/ 8591:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ ProjectSinglePage),
  "getStaticPaths": () => (/* binding */ getStaticPaths),
  "getStaticProps": () => (/* binding */ getStaticProps)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/organisms/Footer/index.tsx
var Footer = __webpack_require__(95);
// EXTERNAL MODULE: ./components/organisms/Navbar/index.tsx + 1 modules
var Navbar = __webpack_require__(8559);
;// CONCATENATED MODULE: ./components/organisms/ProjectBody/index.tsx


function ProjectBody(props) {
    const { type , name , text , dokumentasi  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "w-full",
            children: [
                dokumentasi == "" ? "" : /*#__PURE__*/ jsx_runtime_.jsx("img", {
                    className: `rounded-[10px] w-full md:w-[300px] md:h-[300px] object-cover ${type == "Sebelum" ? "float-left" : "float-right"} ${type == "Sebelum" ? "mr-4" : "ml-4"} mb-1`,
                    src: `https://api.literacypowerid.com/images/${dokumentasi}`,
                    alt: "Project Documentation"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                    className: "font-ptserif font-bold text-base text-main-orange",
                    children: type ? type : name
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    className: "font-ptserif text-justify",
                    children: text
                })
            ]
        })
    });
}

// EXTERNAL MODULE: ./components/organisms/Reviews/index.tsx + 2 modules
var Reviews = __webpack_require__(6056);
;// CONCATENATED MODULE: ./pages/projects/[id].tsx







function ProjectSinglePage({ proyek  }) {
    const cover = proyek.image.split('"');
    console.log(cover[3]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((head_default()), {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("title", {
                    children: [
                        "Literacy Power | ",
                        proyek.nama
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Navbar/* default */.Z, {
                active: "Projects"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                style: {
                    backgroundImage: `url("https://api.literacypowerid.com/images/${cover[1]}")`
                },
                className: `md:h-[300px] lg:h-[350px] bg-cover bg-center relative `,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "absolute w-full h-full bg-main-green/[0.85] flex flex-col justify-center items-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "font-ptserif font-bold text-base md:text-title3 text-light-orange",
                            children: proyek.lokasi
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                            className: "font-ptserif font-bold text-title3 md:text-title2 text-center text-white",
                            children: proyek.nama
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                            className: "font-ptserif font-bold md:text-base text-white bg-light-orange px-2",
                            children: proyek.tanggal
                        })
                    ]
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "w-11/12 max-w-[1000px] mx-auto flex flex-col gap-8 my-5 lg:my-16",
                children: [
                    proyek.content?.length == 0 || undefined ? "" : /*#__PURE__*/ jsx_runtime_.jsx(ProjectBody, {
                        name: proyek.nama,
                        text: proyek.content,
                        dokumentasi: cover[1]
                    }),
                    proyek.content?.length == 0 || undefined ? "" : /*#__PURE__*/ jsx_runtime_.jsx(ProjectBody, {
                        type: "Sebelum",
                        text: proyek.dampak_sebelum,
                        dokumentasi: cover[3]
                    }),
                    proyek.content?.length == 0 || undefined ? "" : /*#__PURE__*/ jsx_runtime_.jsx(ProjectBody, {
                        type: "Sesudah",
                        text: proyek.dampak_sesudah,
                        dokumentasi: cover[5]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Reviews/* default */.Z, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Footer/* default */.Z, {})
        ]
    });
}
const getStaticPaths = async ()=>{
    try {
        const response = await fetch("https://api.literacypowerid.com/api/proyek");
        const data = await response.json();
        // Extract the proyek IDs from the data response
        const proyekIds = data?.data?.map((proyek)=>proyek.id);
        // Generate the paths using the proyek IDs
        const paths = proyekIds.map((id)=>({
                params: {
                    id: id.toString()
                }
            }));
        return {
            paths,
            fallback: false
        };
    } catch (err) {
        console.error(err);
        return {
            paths: [],
            fallback: false
        };
    }
};
const getStaticProps = async ({ params  })=>{
    try {
        const response = await fetch(`https://api.literacypowerid.com/api/proyek/${params.id}`);
        const data = await response.json();
        const proyek = data && data.data && data.data.length > 0 ? data.data[0] : null;
        return {
            props: {
                proyek
            }
        };
    } catch (error) {
        console.error(error);
        return {
            props: {
                proyek: null
            }
        };
    }
};


/***/ }),

/***/ 3280:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 4957:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/head.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 968:
/***/ ((module) => {

module.exports = require("next/head");

/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 8096:
/***/ ((module) => {

module.exports = require("react-slick");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [676,664,675,810,559,95,56], () => (__webpack_exec__(8591)));
module.exports = __webpack_exports__;

})();