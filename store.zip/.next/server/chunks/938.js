"use strict";
exports.id = 938;
exports.ids = [938];
exports.modules = {

/***/ 7938:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "xT": () => (/* binding */ postProyek)
/* harmony export */ });
/* unused harmony export deleteReq */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const Cookie = __webpack_require__(6734);
const token = Cookie.get("token");
const postProyek = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("proyek/postProyek", async (data)=>{
    try {
        const response = await fetch("https://api.literacypowerid.com/api/proyek/", {
            method: "POST",
            headers: {
                "Authorization": "Bearer " + token
            },
            body: data
        });
        const res = await response.json();
        window.location.reload();
    } catch (err) {
        console.log("ini errornya: ", err);
    }
});
const deleteReq = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("proyek/deleteReq", async (id)=>{
    try {
        const deleteReq = await fetch("https://api.literacypowerid.com/api/proyek/" + id, {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + token
            }
        });
        const response = await deleteReq.json();
        console.log(response);
    } catch (err) {
        console.log("error kocak");
    }
});
const proyekSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "proyek",
    initialState: {
        loading: false,
        proyek: [],
        error: null
    },
    reducers: {},
    extraReducers (builder) {
        builder.addCase(postProyek.pending, (state)=>{
            state.loading = true;
        }), builder.addCase(postProyek.fulfilled, (state, action)=>{
            state.loading = false;
            console.log("post success");
        }), builder.addCase(postProyek.rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload;
        }), builder.addCase(deleteReq.fulfilled, (state, action)=>{
            state.loading = false;
            console.log("delete success");
            window.location.reload();
        }), builder.addCase(deleteReq.rejected, (state, action)=>{
            state.loading = false;
            state.error = action.payload;
        });
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (proyekSlice.reducer);


/***/ })

};
;