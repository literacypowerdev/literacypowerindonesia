"use strict";
exports.id = 717;
exports.ids = [717];
exports.modules = {

/***/ 1368:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/logo.2775c13a.svg","height":87,"width":81});

/***/ }),

/***/ 9881:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(8096);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_3__);




const VerticalSlider = ()=>{
    const images = [
        "/images/fotoslider1.png",
        "/images/fotoslider2.png",
        "/images/fotoslider3.png",
        "/images/fotoslider4.png",
        "/images/fotoslider5.png",
        "/images/fotoslider6.png", 
    ];
    const settings = {
        infinite: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        vertical: true,
        autoplay: true,
        speed: 1000,
        autoplaySpeed: 5000,
        verticalSwiping: true,
        beforeChange: function(currentSlide, nextSlide) {
            console.log("before change", currentSlide, nextSlide);
        },
        afterChange: function(currentSlide) {
            console.log("after change", currentSlide);
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "w-72",
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_slick__WEBPACK_IMPORTED_MODULE_3___default()), {
            ...settings,
            children: images.map((image, index)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: "",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                        className: "object-cover z-10 rounded-lg",
                        width: 300,
                        height: 300,
                        src: image,
                        alt: "Dokumentasi"
                    })
                }, index))
        })
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (VerticalSlider);


/***/ }),

/***/ 9931:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ LiteracyFAQ)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./public/icon/accordion-parent.svg
/* harmony default export */ const accordion_parent = ({"src":"/_next/static/media/accordion-parent.3fa48ba7.svg","height":35,"width":35});
;// CONCATENATED MODULE: ./public/icon/accordion-child.svg
/* harmony default export */ const accordion_child = ({"src":"/_next/static/media/accordion-child.f0531968.svg","height":25,"width":25});
// EXTERNAL MODULE: ./node_modules/next/dist/client/image.js
var client_image = __webpack_require__(8045);
var image_default = /*#__PURE__*/__webpack_require__.n(client_image);
;// CONCATENATED MODULE: ./components/molecules/ScheduleTable/index.tsx

const ScheduleTable = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: "font-ptserif",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-black font-extrabold",
                        children: "Hari Pertama (Keberangkatan)"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "Peserta berkumpul di meeting point (Surabaya atau Jakarta, jika di luar Pulau Jawa) untuk berangkat dari pelabuhan menuju desa pengabdian, bersama dengan tim Literacy Power."
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "text-black font-extrabold",
                        children: "Hari Kedua, dstnya"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "Acara penyambutan, perkenalan, dan implementasi program"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("table", {
                    className: "border-collapse w-full md:w-[1000px] border-2 border-slate-800",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                            className: "text-left",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                    className: "border-2 border-slate-800 px-3 py-2 bg-main-orange text-main-background",
                                    children: "Waktu"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                    className: "border-2 border-slate-800 px-3 py-2 bg-main-orange text-main-background",
                                    children: "Kegiatan"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "6.30 pagi"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "Makan pagi"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "7.30 pagi"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "Menuju aula desa untuk penyambutan"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "8.00 - 8.45 pagi"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "Acara penyambutan"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "9.00 pagi - 11.30 siang"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "Kegiatan implementasi program"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "11.45 - 12.30 siang"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "Makan siang, sholat"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "12.50 - 15.30 siang"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "Kegiatan implementasi program selanjutnya"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "15.30 - 17.00 sore"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "Acara bebas"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "17.30 sore - 19.00 malam"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "Istirahat, mandi, makan malam"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "19.30 malam - selesai"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "Evaluasi program, diskusi persiapan program esok hari"
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        className: "font-extrabold",
                        children: "Hari Keenam (Menuju penutupan acara)"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        children: "penutupan acara"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("table", {
                    className: "border-collapse w-full md:w-[865px]",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                            className: "text-left",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                    className: "border-2 border-slate-800 px-3 py-2 bg-main-orange text-main-background",
                                    children: "Waktu"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("th", {
                                    className: "border-2 border-slate-800 px-3 py-2 bg-main-orange text-main-background",
                                    children: "Kegiatan"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "6.30 pagi"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "Makan pagi"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "7.30 pagi"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "Menuju tempat kegiatan program"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "8.00 pagi - 11.30 siang"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "Kegiatan berlangsung"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "11.45 - 12.30 siang"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "Makan siang, sholat"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "12.50 - 17.00 siang"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "Acara bebas dan persiapan penutupan acara"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "17.30 sore - 19.00 malam"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "Istirahat, mandi, makan malam"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("tr", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "19.30 malam - selesai"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("td", {
                                    className: "border-2 border-slate-800 px-3 py-2",
                                    children: "Penutupan acara"
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const molecules_ScheduleTable = (ScheduleTable);

;// CONCATENATED MODULE: ./components/organisms/LiteracyFAQ/index.tsx






const LiteractFAQ = ({ title , details , name  })=>{
    // state
    const { 0: isOpen , 1: setIsOpen  } = (0,external_react_.useState)(false);
    // state
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        "data-aos": "fade-up",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "w-full flex flex-col gap-1 ",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    onClick: ()=>setIsOpen(!isOpen),
                    className: "w-full m-auto bg-white shadow-lg mb-2 hover:bg-main-green text-gray-600 hover:text-white transition-all duration-150 ease-in-out cursor-pointer px-5 py-2 rounded-[20px] flex justify-between",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "flex gap-2",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: accordion_parent,
                                    width: 20,
                                    height: 20,
                                    alt: ""
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                                    className: " font-ptserif font-bold",
                                    children: title
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: "/icon/accordion-arrow.svg",
                            alt: "",
                            className: "w-[16px]"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: `w-full flex flex-col gap-1 mb-2 ${isOpen ? "" : "hidden"}`,
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full m-auto bg-main-background mb-1 shadow-lg transition-all duration-150 ease-in-out cursor-pointer px-5 py-5 rounded-[20px] flex justify-start gap-2",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "flex flex-col",
                            children: name != "jadwal" ? /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    className: "flex flex-col gap-2",
                                    children: details.map((item, index)=>{
                                        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex gap-2 items-center",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    src: accordion_child,
                                                    width: 20,
                                                    height: 20,
                                                    alt: ""
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: item
                                                })
                                            ]
                                        }, index);
                                    })
                                })
                            }) : /*#__PURE__*/ jsx_runtime_.jsx(molecules_ScheduleTable, {})
                        })
                    })
                })
            ]
        })
    });
// // state
// return (
//   <div data-aos="fade-up">
//     <div className="w-full flex flex-col gap-1 ">
//       <div
//         onClick={() => setIsOpen(!isOpen)}
//         className="w-full m-auto bg-white shadow-lg mb-2 hover:bg-main-green text-gray-600 hover:text-white transition-all duration-150 ease-in-out cursor-pointer px-5 py-2 rounded-[20px] flex justify-between"
//       >
//         <div className="flex gap-2">
//           <Image src={AccordionParent} width={20} height={20} />
//           <h2 className=" font-ptserif font-bold">{title}</h2>
//         </div>
//         <img src="/icon/accordion-arrow.svg" alt="" className="w-[16px]" />
//       </div>
//       <div
//         className={`w-full flex flex-col gap-1 mb-2 ${
//           isOpen ? "" : "hidden"
//         }`}
//       >
//         <div className="w-full m-auto bg-main-background mb-1 shadow-lg transition-all duration-150 ease-in-out cursor-pointer px-5 py-2 rounded-[20px] flex justify-start  gap-2">
//           <div className="flex flex-col">
//             <ul>
//               <li className="flex flex-col gap-2">
//                 {details.map((item) => {
//                   return (
//                     <div className="flex gap-2 items-center">
//                       <Image src={AccordionChild} width={20} height={20} />
//                       <p>{item}</p>
//                     </div>
//                   );
//                 })}
//               </li>
//             </ul>
//           </div>
//         </div>
//       </div>
//     </div>
//   </div>
// );
};
/* harmony default export */ const LiteracyFAQ = (LiteractFAQ);


/***/ })

};
;