"use strict";
exports.id = 925;
exports.ids = [925];
exports.modules = {

/***/ 5925:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "_L": () => (/* binding */ setQuery)
/* harmony export */ });
/* unused harmony exports getBuku, getBukuById, postBuku, deleteBuku */
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2167);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);


const Cookie = __webpack_require__(6734);
const getBuku = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("buku/getBuku", async ()=>{
    try {
        const response = await axios__WEBPACK_IMPORTED_MODULE_1___default().get("https://api.literacypowerid.com/api/buku");
        const data = await response.data.data;
        return data;
    } catch (err) {
        console.error(err);
    }
});
// optional
const getBukuById = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("buku/getBukuById", async (id)=>{
    try {
        const response = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(`https://api.literacypowerid.com/api/buku/${id}`);
        const data = await response.data.data;
        return data;
    } catch (err) {
        console.log(err);
    }
});
// pr belum dirapihin
const postBuku = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("buku/postBuku", async (bookData, token)=>{
    try {
        const create = await fetch("https://api.literacypowerid.com/api/buku", {
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + token
            },
            body: JSON.stringify(bookData)
        });
        const response = await create.json();
        console.log(response);
    } catch (error) {
        console.log(error);
    }
});
const deleteBuku = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("buku/deleteBuku", async (id)=>{
    const cookieToken = Cookie.get("token");
    try {
        const deleteReq = await fetch(`https://api.literacypowerid.com/api/buku/${id}`, {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + cookieToken
            }
        });
        const response = await deleteReq.json();
        console.log(response);
    } catch (err) {
        console.log(err);
        Cookie.remove("token");
    }
});
// type initialStateProps
const bukuSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "buku",
    initialState: {
        loading: false,
        data: [],
        query: "",
        error: null
    },
    reducers: {
        setQuery (state, action) {
            state.query = action.payload;
        }
    },
    extraReducers (builder) {
        builder.addCase(getBuku.pending, (state)=>{
            state.loading = true;
        }), builder.addCase(getBuku.fulfilled, (state, action)=>{
            state.loading = false, state.data = action.payload;
        }), builder.addCase(getBuku.rejected, (state, action)=>{
            state.loading = false, state.error = action.payload;
        }), builder.addCase(getBukuById.pending, (state)=>{
            state.loading = true;
        }), builder.addCase(getBukuById.fulfilled, (state, action)=>{
            state.loading = false, state.data = action.payload;
        }), builder.addCase(getBukuById.rejected, (state, action)=>{
            state.loading = false, state.error = action.payload;
        }), builder.addCase(deleteBuku.fulfilled, (state, action)=>{
            state.loading = false;
            console.log("doiwjadioawj");
        // window.location.reload();
        }), builder.addCase(deleteBuku.rejected, (state, action)=>{
            state.error = action.payload;
            console.log(state.error);
        });
    }
});
const { setQuery  } = bukuSlice.actions;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (bukuSlice.reducer);


/***/ })

};
;