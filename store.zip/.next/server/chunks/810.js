"use strict";
exports.id = 810;
exports.ids = [810];
exports.modules = {

/***/ 6810:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Button)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function Button(props) {
    const { text , disable , link , runOnClick , border , size , animate  } = props;
    const style = {
        normal: "py-1",
        large: "py-2",
        full: "rounded-full",
        rectangle: "rounded-md",
        animate: "animate-bounce"
    };
    const styles = `${disable ? "opacity-70 cursor-default hover:bg-main-green active:bg-main-green" : ""} bg-main-green ${style[size]} h-fit w-full ${style[border]} flex justify-center items-center transition-colors duration-150 ease-in-out hover:bg-[#596E67] active:bg-[#42524C] `;
    //   Button as link
    //   Bungkus componenya pake tag Link
    if (link) {
        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
            className: `${styles} cursor-pointer ${animate ? "animate-bounce" : ""}`,
            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "text-white font-ptserif",
                children: text
            })
        });
    }
    //   Button calls function
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
        disabled: disable,
        onClick: runOnClick ?? (()=>null),
        className: styles,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
            className: "text-white font-ptserif",
            children: text
        })
    });
}


/***/ })

};
;