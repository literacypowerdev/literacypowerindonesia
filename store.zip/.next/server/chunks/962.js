"use strict";
exports.id = 962;
exports.ids = [962];
exports.modules = {

/***/ 7962:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ layout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/admin/sidebar.tsx



const Sidebar = ()=>{
    const menuItems = [
        {
            id: 1,
            label: "Back to Home",
            link: "/"
        },
        {
            id: 2,
            label: "Manage Buku",
            link: "/admin/dashboard/buku"
        },
        {
            id: 3,
            label: "Manage Review",
            link: "/admin/dashboard/review"
        },
        {
            id: 4,
            label: "Manage Proyek",
            link: "/admin/dashboard/proyek"
        },
        {
            id: 5,
            label: "Manage Galery",
            link: "/admin/dashboard/galery"
        },
        {
            id: 6,
            label: "Manage Article",
            link: "/admin/dashboard/article"
        }, 
    ];
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "bg-very-light-orange h-fit p-6",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "min-w-[300px]",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "p-3 font-bold",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("h1", {
                        children: "Literacy Power Dashboard"
                    })
                }),
                menuItems.map((item, index)=>{
                    return /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: item.link,
                            children: /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                className: "cursor-pointer hover:bg-main-green hover:text-white p-2 font-medium",
                                children: item.label
                            })
                        })
                    }, index);
                })
            ]
        })
    });
};
/* harmony default export */ const sidebar = (Sidebar);

;// CONCATENATED MODULE: ./components/admin/layout.tsx



const Layout = ({ children  })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "h-screen flex flex-row justify-start",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(sidebar, {}),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "bg-primary flex flex-col p-4 text-white",
                    children: children
                })
            ]
        })
    });
};
/* harmony default export */ const layout = (Layout);


/***/ })

};
;