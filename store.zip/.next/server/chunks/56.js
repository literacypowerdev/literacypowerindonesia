"use strict";
exports.id = 56;
exports.ids = [56];
exports.modules = {

/***/ 6056:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ organisms_Reviews)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/atoms/Button/index.tsx
var Button = __webpack_require__(6810);
// EXTERNAL MODULE: external "react-slick"
var external_react_slick_ = __webpack_require__(8096);
var external_react_slick_default = /*#__PURE__*/__webpack_require__.n(external_react_slick_);
;// CONCATENATED MODULE: ./components/organisms/Reviews/slider.tsx
const ReviewSlider = [
    {
        "id": "1",
        "reviews": "“Pengalaman memorable banget bisa mengikuti volunteering bersama Literacy Power, membagikan buku donasi untuk adik-adik di pesantren Para stakeholder pun sangat antusias membantu kami. Tempatnya pun sangat nyaman dan indah, masih hijau meskipun memakan cukup waktu yang lama dari kota.”",
        "reviewer": "Adin, Mahasiswa Universitas Pendidikan Indonesia"
    },
    {
        "id": "2",
        "reviews": "“Pengalaman memorable banget bisa mengikuti volunteering bersama Literacy Power, membagikan buku donasi untuk adik-adik di pesantren Para stakeholder pun sangat antusias membantu kami. Tempatnya pun sangat nyaman dan indah, masih hijau meskipun memakan cukup waktu yang lama dari kota.”",
        "reviewer": "Adin, Mahasiswa Universitas Pendidikan Indonesia"
    },
    {
        "id": "3",
        "reviews": "“Pengalaman memorable banget bisa mengikuti volunteering bersama Literacy Power, membagikan buku donasi untuk adik-adik di pesantren Para stakeholder pun sangat antusias membantu kami. Tempatnya pun sangat nyaman dan indah, masih hijau meskipun memakan cukup waktu yang lama dari kota.”",
        "reviewer": "Adin, Mahasiswa Universitas Pendidikan Indonesia"
    }
];

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/icon/quotes.svg
/* harmony default export */ const quotes = ({"src":"/_next/static/media/quotes.d7e2cdb8.svg","height":35,"width":54});
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/organisms/Reviews/index.tsx










const Reviews = (props)=>{
    const { isReview  } = props;
    const settings = {
        dots: false,
        infinite: true,
        speed: 500,
        slidesToShow: 1,
        slidesToScroll: 1
    };
    const data = ReviewSlider;
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: "bg-main-orange py-5",
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: "w-11/12 md:w-10/12 mx-auto flex flex-col md:flex-row lg:justify-around justify-between items-center ",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "Left flex flex-col gap-4",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "Bergabung text-white font-bold text-title2 text-center md:text-left font-ptserif",
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h1", {
                                children: [
                                    isReview ? "Bergabung" : "Apa",
                                    /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                    isReview ? "Dengan Kami!" : "Kata Mereka?"
                                ]
                            })
                        }),
                        isReview ? /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/apply",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "Button font-bold max-w-[400px] min-w-[200px]",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                    text: "Apply",
                                    link: true,
                                    size: "normal",
                                    border: "full"
                                })
                            })
                        }) : /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                            href: "/reviews",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: "Button font-bold max-w-[400px] min-w-[200px]",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                    text: "See More Reviews",
                                    size: "normal",
                                    border: "full"
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: "Slider w-full md:w-fit text-left md:text-justify p-5",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "bg-white mx-auto rounded-lg py-5 w-full max-w-[500px] md:w-[400px]",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((external_react_slick_default()), {
                            ...settings,
                            children: data.map((item)=>{
                                return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "!flex flex-col gap-2 px-8",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "font-semibold",
                                            children: item.reviews
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            className: "font-semibold text-orange-500 text-xl",
                                            children: "Good job for the team!"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "flex items-center justify-between",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    className: "font-semibold",
                                                    children: item.reviewer
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                                    src: quotes,
                                                    width: 80,
                                                    height: 80,
                                                    alt: "Quote"
                                                })
                                            ]
                                        })
                                    ]
                                }, item.id);
                            })
                        })
                    })
                })
            ]
        })
    });
};
/* harmony default export */ const organisms_Reviews = (Reviews);


/***/ })

};
;