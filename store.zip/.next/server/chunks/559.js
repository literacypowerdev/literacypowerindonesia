"use strict";
exports.id = 559;
exports.ids = [559];
exports.modules = {

/***/ 8559:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Navbar)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/atoms/Button/index.tsx
var Button = __webpack_require__(6810);
;// CONCATENATED MODULE: ./components/organisms/Navbar/MobileMenu.tsx




function MobileMenu(props) {
    const { toggleOpen  } = props;
    const { 0: isProgramsOpen , 1: setIsProgramsOpen  } = (0,external_react_.useState)(false);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: `${toggleOpen ? "" : "translate-y-[-600px]"} md:hidden w-full h-fit bg-white absolute z-10 transition duration-300 ease-in-out`,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                        onClick: ()=>setIsProgramsOpen(!isProgramsOpen),
                        className: "w-100 py-4 px-6 text-main-orange hover:text-white font-ptserif cursor-pointer transition duration-150 ease-in-out hover:bg-light-orange",
                        children: "Divisions"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/divisions/kesehatan",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: `${isProgramsOpen ? "block" : "hidden"} w-100 py-4 px-12 text-main-orange hover:text-white font-ptserif transition duration-150 ease-in-out hover:bg-light-orange`,
                            children: "Kesehatan"
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/divisions/pendidikan",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: `${isProgramsOpen ? "block" : "hidden"} w-100 py-4 px-12 text-main-orange hover:text-white font-ptserif transition duration-150 ease-in-out hover:bg-light-orange`,
                            children: "Pendidikan"
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/divisions/lingkungan",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: `${isProgramsOpen ? "block" : "hidden"} w-100 py-4 px-12 text-main-orange hover:text-white font-ptserif transition duration-150 ease-in-out hover:bg-light-orange`,
                            children: "Lingkungan"
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/divisions/ekonomi",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: `${isProgramsOpen ? "block" : "hidden"} w-100 py-4 px-12 text-main-orange hover:text-white font-ptserif transition duration-150 ease-in-out hover:bg-light-orange`,
                            children: "Ekonomi"
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/programs",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: "block w-100 py-4 px-6 text-main-orange hover:text-white font-ptserif transition duration-150 ease-in-out hover:bg-light-orange",
                            children: "Programs"
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/projects",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: "block w-100 py-4 px-6 text-main-orange hover:text-white font-ptserif transition duration-150 ease-in-out hover:bg-light-orange",
                            children: "Projects"
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/reviews",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: "block w-100 py-4 px-6 text-main-orange hover:text-white font-ptserif transition duration-150 ease-in-out hover:bg-light-orange",
                            children: "Reviews"
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/allaboutbooks",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                            className: "block w-100 py-4 px-6 text-main-orange hover:text-white font-ptserif transition duration-150 ease-in-out hover:bg-light-orange",
                            children: "All About Books"
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                        href: "/apply",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "w-[100px] mx-5 mt-2 mb-5",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                text: "Apply",
                                border: "full",
                                size: "normal"
                            })
                        })
                    })
                })
            ]
        })
    });
}

;// CONCATENATED MODULE: ./components/organisms/Navbar/index.tsx






function Navbar(props) {
    const { active  } = props;
    const { 0: isOpen , 1: setIsOpen  } = (0,external_react_.useState)(false);
    const { 0: isProgramsOpen , 1: setIsProgramsOpen  } = (0,external_react_.useState)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
        className: "z-30",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "w-full h-[90px] md:h-[100px] bg-main-orange flex justify-center relative z-20",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: "w-11/12 md:w-11/12 h-full flex justify-between items-center",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "w-[72px] md:w-[82px] h-full py-2 cursor-pointer",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/",
                                passHref: true,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: "",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: "/icon/logo.svg",
                                        alt: "Logo",
                                        width: "100%",
                                        height: "100%"
                                    })
                                })
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            onMouseLeave: ()=>setIsProgramsOpen(false),
                            className: "w-fit h-full sm:gap-5 md:gap-8 lg:gap-16 xl:gap-28 hidden md:flex items-center",
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                    className: "relative",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                            onMouseEnter: ()=>setIsProgramsOpen(true),
                                            className: `text-white font-ptserif cursor-pointer ${active == "Divisions" ? "underline" : ""}`,
                                            children: "Divisions"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                            onMouseEnter: ()=>setIsProgramsOpen(true),
                                            onMouseLeave: ()=>setIsProgramsOpen(false),
                                            className: `${isProgramsOpen ? "" : "hidden"} w-[150px] h-fit bg-white absolute rounded-md overflow-hidden top-8`,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/divisions/pendidikan",
                                                        passHref: true,
                                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                            className: "text-main-orange block w-full px-4 py-2 font-ptserif cursor-pointer transition duration-150 ease-in-out hover:bg-light-orange hover:text-white",
                                                            children: [
                                                                "Literasi ",
                                                                /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                                                                " Sekolah"
                                                            ]
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/divisions/lingkungan",
                                                        passHref: true,
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            className: "text-main-orange block w-full px-4 py-2 font-ptserif cursor-pointer transition duration-150 ease-in-out hover:bg-light-orange hover:text-white",
                                                            children: "Literasi Lingkungan"
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/divisions/ekonomi",
                                                        passHref: true,
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            className: "text-main-orange block w-full px-4 py-2 font-ptserif cursor-pointer transition duration-150 ease-in-out hover:bg-light-orange hover:text-white",
                                                            children: "Literasi Ekonomi"
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                                        href: "/divisions/kesehatan",
                                                        passHref: true,
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            className: "text-main-orange block w-full px-4 py-2 font-ptserif cursor-pointer transition duration-150 ease-in-out hover:bg-light-orange hover:text-white",
                                                            children: "Literasi Kesehatan"
                                                        })
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/programs",
                                        passHref: true,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            className: `text-white font-ptserif ${active == "Programs" ? "underline" : ""}`,
                                            children: "Programs"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/projects",
                                        passHref: true,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            className: `text-white font-ptserif ${active == "Projects" ? "underline" : ""}`,
                                            children: "Projects"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/reviews",
                                        passHref: true,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            className: `text-white font-ptserif ${active == "Reviews" ? "underline" : ""}`,
                                            children: "Reviews"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/article",
                                        passHref: true,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            className: `text-white font-ptserif ${active == "Article" ? "underline" : ""}`,
                                            children: "Article"
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                        href: "/allaboutbooks",
                                        passHref: true,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            className: `text-white font-ptserif ${active == "All About Books" ? "underline" : ""}`,
                                            children: "All About Books"
                                        })
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "hidden md:flex justify-center items-center rounded-full",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                                href: "/apply",
                                passHref: true,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: "w-[100px] lg:w-[125px]",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Button/* default */.Z, {
                                        text: "Apply",
                                        link: true,
                                        border: "full",
                                        size: "large",
                                        animate: true
                                    })
                                })
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "w-[28px] h-[24px] flex flex-col justify-between md:hidden cursor-pointer",
                            onClick: ()=>setIsOpen(!isOpen),
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: `w-full h-[2px] bg-white transition duration-300 ease-in-out ${isOpen ? "rotate-45 translate-y-[11px]" : ""}`
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: `w-full h-[2px] bg-white transition duration-300 ease-in-out ${isOpen ? "scale-0 opacity-0" : ""}`
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    className: `w-full h-[2px] bg-white transition duration-300 ease-in-out ${isOpen ? "-rotate-45 translate-y-[-11px]" : ""}`
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(MobileMenu, {
                toggleOpen: isOpen
            })
        ]
    });
}


/***/ })

};
;