"use strict";
exports.id = 613;
exports.ids = [613];
exports.modules = {

/***/ 8613:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "QO": () => (/* binding */ deleteReq),
/* harmony export */   "ZP": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "Zu": () => (/* binding */ postReview)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5184);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__);

const Cookie = __webpack_require__(6734);
// token
const CookieToken = Cookie.get("token");
const postReview = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("review/postReview", async (data)=>{
    const cookieToken = Cookie.get("token");
    try {
        const postReq = await fetch("https://api.literacypowerid.com/api/review", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + cookieToken
            },
            body: JSON.stringify(data)
        });
        const response = await postReq.json();
        console.log(response);
    } catch (err) {
        console.log("error kocak");
    }
});
const deleteReq = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createAsyncThunk)("review/deleteReq", async (id)=>{
    try {
        const deleteReq = await fetch(`https://api.literacypowerid.com/api/review/${id}`, {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer " + CookieToken
            }
        });
        const response = await deleteReq.json();
        console.log(response);
    } catch (err) {
        console.log("error kocak");
    }
});
const reviewSlice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_0__.createSlice)({
    name: "review",
    initialState: {
        loading: false,
        data: [],
        error: null
    },
    reducers: {},
    extraReducers (builder) {
        builder.addCase(postReview.fulfilled, (state, action)=>{
            state.loading = false, console.log("alhamdullilah");
            window.location.reload();
        }), builder.addCase(deleteReq.fulfilled, (state, action)=>{
            state.loading = false;
            window.location.reload();
        }), builder.addCase(deleteReq.rejected, (state, action)=>{
            state.error = action.payload;
            console.log("rejected");
        });
    }
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (reviewSlice.reducer);


/***/ })

};
;